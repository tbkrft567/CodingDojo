from django.apps import AppConfig


class PythonappConfig(AppConfig):
    name = 'pythonApp'
