FactoryBot.define do
  factory :member do
    user { nil }
    group { nil }
  end
end
